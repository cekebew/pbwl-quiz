

<?php $__env->startSection('content'); ?>
    <h2>Edit Golongan</h2>

  <form action="<?php echo e(route('pel_update', ['id' => $row->id])); ?>" method="POST">
    
        <input type="hidden" name="_method" value="PUT">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="id">Golongan:</label>
            <select class="form-select" id="id" name="gol_id" required>
                <?php $__currentLoopData = $golongans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $golongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($golongan->id); ?>"><?php echo e($golongan->gol_nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="">No Pelanggan</label>
            <input type="text" name="pel_no" id="" class="form-control" value="<?php echo e($row->pel_no); ?>">
        </div>
        <div class="mb-3">
            <label for="">Nama Pelanggan</label>
            <input type="text" name="pel_nama" id="" class="form-control" value="<?php echo e($row->pel_nama); ?>">
        </div>
        <div class="mb-3">
            <label for="">Alamat</label>
            <input type="text" name="pel_alamat" id="" class="form-control" value="<?php echo e($row->pel_alamat); ?>">
        </div>
        <div class="mb-3">
            <label for="">No Hp</label>
            <input type="text" name="pel_hp" id="" class="form-control" value="<?php echo e($row->pel_hp); ?>">
        </div>
        <div class="mb-3">
            <label for="">KTP</label>
            <input type="text" name="pel_ktp" id="" class="form-control" value="<?php echo e($row->pel_ktp); ?>">
        </div>
        <div class="mb-3">
            <label for="">Seri</label>
            <input type="text" name="pel_seri" id="" class="form-control" value="<?php echo e($row->pel_seri); ?>">
        </div>
        <div class="mb-3">
            <label for="">Meteran</label>
            <input type="text" name="pel_meteran" id="" class="form-control" value="<?php echo e($row->pel_meteran); ?>">
        </div>
        <div class="mb-3">
            <label for="pel_aktif">Aktif:</label>
            <select name="pel_aktif" class="form-select" required>
                <option value="">Pilih Status</option>
                <option value="Y">Aktif</option>
                <option value="N">Non Aktif</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="id">User:</label>
            <select class="form-select" id="id" name="user_id" required>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <input type="submit" value="UPDATE" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quizdiva-pbwl\resources\views/pelanggan/edit.blade.php ENDPATH**/ ?>