

<?php $__env->startSection('content'); ?>
    <h2>Edit Category</h2>

    <form action="<?php echo e(url('categories/' . $row->cat_id)); ?>" method="post">
        <input type="hidden" name="_method" value="PATCH">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="">NAME</label>
            <input type="text" name="cat_name" id="" class="form-control" value="<?php echo e($row->cat_name); ?>">
        </div>
        <div class="mb-3">
            <input type="submit" value="UPDATE" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl-project11\resources\views/categories/edit.blade.php ENDPATH**/ ?>